The images folder
